import React from 'react'
import Table from './components/table.jsx'; 
import Form from './components/form.jsx'; 
import { Provider } from 'react-redux';
import store from './redux/store';

function App() {
  return (
    <Provider store={store}>
      <div className="App">
        <Form />
      </div>
    </Provider>
  );
}

export default App;
