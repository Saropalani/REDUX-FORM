import React, { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { FaCheckCircle } from 'react-icons/fa';
import Table from './table.jsx'
import { addData, validateData, editData, deleteData } from "../redux/actions.jsx";

function Form() {
  const dispatch = useDispatch();
  const data = useSelector(state => state.data);

  const [details, setDetails] = useState({
    'Employee Name': '',
    'Gender': '',
    'Department': '',
    'Date of Join': '',
    'Email': ''
  });

  const initialValues = {
    'Employee Name': '',
    'Gender': '',
    'Department': '',
    'Date of Join': '',
    'Email': ''
  };
  const [formError, setFormError] = useState({});
  const [formSuccess, setFormSuccess] = useState('');
  const [editIndex, setEditIndex] = useState(null);
  const [isSubmit, setIsSubmit] = useState(false);

  const handleChange = (event) => {
    const { name, value } = event.target;
    setDetails(prevDetails => ({
      ...prevDetails,
      [name]: value
    }));

    setFormSuccess(prevState => ({
      ...prevState,
      [name]: value.trim() !==''
    }));
  };

  const editRow = (rowData) => {
    const index = data.findIndex(item => item === rowData);
    if (index !== -1) {
      setDetails(rowData);
      setEditIndex(index); 
    }
  }

  const handleSubmit = (event) => {
    event.preventDefault();
    
    const errors = validate(details);
    setFormError(errors);

    if ( !details['Employee Name'] || !details['Gender'] || !details['Department'] || !details['Date of Join'] || !details['Email'] ) {
      return; 
    }

    if (Object.keys(errors).length === 0) {
      if (editIndex !== null) {
        dispatch(editData(editIndex, details));
        setEditIndex(null);
      } else {
        dispatch(addData(details));
      }
      setDetails(initialValues);
      setFormSuccess('');
      setIsSubmit(true);
    } else {
      setIsSubmit(false);
    }
  };

  const validate = (values) => {
    const errors = {};
    const regex = /^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[A-Za-z]+$/;

    if (!values['Employee Name']) {
      errors['Employee Name'] = "Name is required";
    } 
    if (!values['Gender']) {
      errors['Gender'] = "Field is not filled";
    }
    if (!values['Department']) {
      errors['Department'] = "Field is not filled";
    }
    if (!values['Date of Join']) {
      errors['Date of Join'] = "Please enter a valid input";
    }
    if (!values['Email']) {
      errors['Email'] = "Email is required";
    } else if (!regex.test(values['Email'])) {
      errors['Email'] = "Please enter a valid email";
    }
    return errors;
  };

  return (
    <div>
      <form className='form-container' onSubmit={handleSubmit}>
        <h2 className='header'>FORM REGISTRATION</h2>
        <div className='input-group'>
          <label htmlFor='employeeName'>Employee Name</label>
          <input
            type='text'
            className={`input-field ${formSuccess['Employee Name'] ? 'success' : formError['Employee Name'] ? 'error' : ''}`}
            id='employeeName'
            name='Employee Name'
            value={details['Employee Name']}
            onChange={handleChange}
            style={{ border: formSuccess['Employee Name'] ? '2px solid green' : formError['Employee Name'] ? '2px solid red' : ''}}
          />
          {formSuccess['Employee Name'] && <FaCheckCircle className='fa-fa-circle' />}
          {!formSuccess['Employee Name'] && <div className='error' id='nameError'>{formError['Employee Name']}</div>}
        </div>


        <br />
        <div className='input-group'>
          <label htmlFor='gender'>Gender</label>
          <select
            id='gender'
            name='Gender'
            className={`input-field ${formSuccess['Gender'] ? 'success' : ''}`}
            value={details['Gender']}
            onChange={handleChange}
            style={{ border: formSuccess['Gender'] ? '2px solid green' : formError['Gender'] ? '2px solid red' : ''}}
          >
            <option value=''>Select Gender</option>
            <option value='Male'>Male</option>
            <option value='Female'>Female</option>
            <option value='Others'>Others</option>
          </select>
          {!formSuccess['Gender'] && <div className='error' id='genderError'>{formError['Gender']}</div>}
        </div>

        <br />
        <div className='input-group'>
          <label htmlFor='department'>Department</label>
          <select
            id='department'
            className={`input-field ${formSuccess['Department'] && details['Department'] ? 'success' : ''}`}
            name='Department'
            value={details['Department']}
            onChange={handleChange}
            style={{ border: formSuccess['Department'] && details['Department'] ? '2px solid green' : formError['Department'] ? '2px solid red' : ''}}
          >
            <option value=''>Select Department</option>
            <option value='Operation'>Operation</option>
            <option value='Analytics'>Analytics</option>
            <option value='Marketing'>Marketing</option>
            <option value='Sales'>Sales</option>
          </select>
          {!formSuccess['Department'] && <div className='error' id='deptError'>{formError['Department']}</div>}
        </div>

       <br />
       <div className='input-group'>
          <label htmlFor='dateofJoin'>Date of Join</label>
          <input
            type='date'
            className={`input-field ${formSuccess['Date of Join'] ? 'success' : ''}`}
            id='dateofJoin'
            name='Date of Join'
            value={details['Date of Join']}
            onChange={handleChange}
            style={{ border: formSuccess['Date of Join'] ? '2px solid green' : formError['Date of Join'] ? '2px solid red' : ''}}
          />
          {!formSuccess['Date of Join'] && <div className='error' id='dateError'>{formError['Date of Join']}</div>}
        </div>

      <br />

      <div className='input-group'>
        <label htmlFor='email'>Email</label>
        <input
          type='email'
          className={`input-field ${formSuccess['Email'] ? 'success' : ''}`}
          placeholder='example@gmail.com'
          id='email'
          name='Email'
          value={details['Email']}
          onChange={handleChange}
          style={{ border: formSuccess['Email'] ? '2px solid green' : formError['Email'] ? '2px solid red' : ''}}
        />
        {formSuccess['Email'] && <FaCheckCircle className='fa-fa-circle' />}
        {!formSuccess['Email'] && <div className='error' id='emailError'>{formError['Email']}</div>}
      </div>

        <br />

        <div>
        <button type="submit" className="submit-button">{editIndex !== null ? 'Update' : 'Submit'}</button>
          <button type='reset' className='reset' onClick={() => { setDetails(initialValues);
              setFormSuccess({});
              setFormError({});
           }}>Reset</button>

        </div>
      </form>
      {data.length > 0 && <Table editRow={editRow} />}
    </div>
  );
}

export default Form;
