import React, { useMemo } from "react";
import { useSelector, useDispatch } from "react-redux";
import { useTable, useSortBy } from 'react-table';
import { FaSort } from 'react-icons/fa';
import { FaTrash, FaEdit } from 'react-icons/fa';
import { editData, deleteData, sortData } from "../redux/actions";

function Table({ editRow }) {
  const data = useSelector(state => state.data);
  const dispatch = useDispatch();

  const handleSort = (column) => {
      dispatch(sortData(column));
  };

  const handleDelete = (rowIndex) => {
    if (rowIndex >= 0 && rowIndex < data.length) {
        let total = [...data];
        total.splice(rowIndex, 1);
        dispatch(deleteData(rowIndex));
    } else {
        console.error("Invalid row index:", rowIndex);
    }
  }

  const columns = useMemo(
    () => [
      { Header: 'Employee Name', accessor: 'Employee Name' },
      { Header: 'Gender', accessor: 'Gender' },
      { Header: 'Department', accessor: 'Department' },
      { Header: 'Date of Join', accessor: 'Date of Join' },
      { Header: 'Email', accessor: 'Email' },
      {
        Header: 'Action',
        accessor: 'Action',
        disableSortBy: true,
        Cell: ({ row, rowIndex }) => (
          <div className="action">
            <FaTrash onClick={() => handleDelete(row.index)} className="fa-trash" />
            <FaEdit onClick={() => editRow(row.original)} className="fa-edit" />
          </div>
        )
      }
    ],
    [editRow]
  );

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
    },
    useSortBy
  );

  return (
    <table
      id='table'
      className='table-container'
      style={{ display: data.length === 0 ? 'none' : 'table' }}
      {...getTableProps()}>
      <thead>
        {headerGroups.map((headerGroup) => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map((column) => (
              <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                {column.render('Header')}
                {column.id !== 'Action' &&
                  (<span>
                    {column.isSorted ? (column.isSortedDesc ? '▼ ' : '▲') : <FaSort />}
                  </span>)}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows && rows.map((row, rowIndex) => {
          prepareRow(row);
          return (
            <tr key={rowIndex} {...row.getRowProps()}>
              {row.cells.map((cell, cellIndex) => (
                <td key={cellIndex} {...cell.getCellProps()}>
                  {cell.render('Cell')}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

export default Table;
