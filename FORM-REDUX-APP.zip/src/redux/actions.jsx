import * as actionTypes from './actiontypes'; 

export const addData = (details) => ({ 
  type: actionTypes.ADD_DATA,
  payload: details
});

export const validateData = (errors) => ({ 
  type: actionTypes.VALIDATE_DATA,
  payload: errors
});

export const sortData = (column, direction) => ({ 
  type: actionTypes.SORT_DATA,
  payload: { column, direction }
});

export const editData = (index, details) => ({
  type: actionTypes.EDIT_DATA,
  payload: { index, details } 
});

export const deleteData = (index) => ({
  type: actionTypes.DELETE_DATA,
  payload: index
});
