import { ADD_DATA, VALIDATE_DATA, SORT_DATA, EDIT_DATA, DELETE_DATA } from './actiontypes'

const initialState = {
  data: [],
  formErrors: {}
};

const rootReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_DATA:
      return{
        ...state,
        data: [...state.data, action.payload]
      };
     
    case VALIDATE_DATA:
      return {
        ...state,
        data: [...state.data, action.payload]
      } ;
      
     case VALIDATE_DATA:
      return {
        ...state,
        formErrors: action.payload
      } ;
      
      case SORT_DATA:
        const { column, direction } = action.payload;
        const sortedData = [...state.data].sort((a, b) => {
          if (direction === 'asc') {
            return a[column] > b[column] ? 1 : -1;
          } else {
            return a[column] < b[column] ? 1 : -1;
          }
        });
        return {
          ...state,
          data: sortedData
        };

        case EDIT_DATA:
          const { index, details } = action.payload;
          const updatedData = [...state.data];
          updatedData[index] = details;
          return {
            ...state,
            data: updatedData
  };

      case DELETE_DATA:
        const dataIndex = action.payload;
        const newData = [...state.data];
        newData.splice(dataIndex, 1);
        return { 
          ...state,
          data: newData
        };
        default:
          return state;


  }
};

export default rootReducer;